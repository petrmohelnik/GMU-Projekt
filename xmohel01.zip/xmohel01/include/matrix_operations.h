void determinant(float *, float *, int *, int);
void gem(float *, float *, int);
void inverse(float *, float *, int);