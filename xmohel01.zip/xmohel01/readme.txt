makra v main.cpp:
SIZE - velikost matice
PRINT_MATRIX - zapnut/vypnut vypis matic